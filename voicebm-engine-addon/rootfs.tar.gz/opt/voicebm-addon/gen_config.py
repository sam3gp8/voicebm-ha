#!/usr/bin/env python3
"""
gen_config.py — builds /share/voicebm/config.json from the add-on's
/data/options.json, in the exact schema upstream's setup_voicebm.sh wizard
produces (see build_config() in setup_voicebm.sh). Run once at container
start by the init-voicebm-config s6 oneshot, and again whenever the add-on
restarts (so a Supervisor "Save" -> restart picks up new options).

MQTT broker/port/user/password are resolved by the calling shell (which has
bashio and can read the Supervisor's mqtt service) and passed in via env:
  MQTT_BROKER, MQTT_PORT, MQTT_USER, MQTT_PASS
Everything else is read straight from options.json.
"""
import json
import os
import socket
import sys

OPTIONS_PATH = "/data/options.json"
CONFIG_OUT = os.environ.get("VOICEBM_CONFIG_OUT", "/share/voicebm/config.json")

VOICEBM_BASE = "/home/user/voicebm"
SHERPA_BIN = "/home/user/.local/bin/sherpa_embed.py"
SHERPA_MODEL = "/home/user/sherpa_models/nemo_en_titanet_small.onnx"


def load_options():
    try:
        with open(OPTIONS_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"WARNING: {OPTIONS_PATH} not found, using empty options", file=sys.stderr)
        return {}


def main():
    opts = load_options()

    mqtt_broker = os.environ.get("MQTT_BROKER") or opts.get("mqtt", {}).get("broker", "")
    mqtt_port = int(os.environ.get("MQTT_PORT") or opts.get("mqtt", {}).get("port", 1883) or 1883)
    mqtt_user = os.environ.get("MQTT_USER") or opts.get("mqtt", {}).get("username", "")
    mqtt_pass = os.environ.get("MQTT_PASS") or opts.get("mqtt", {}).get("password", "")

    net = opts.get("network", {}) or {}
    public_host = net.get("public_host") or socket.gethostname()

    comp = opts.get("components", {}) or {}
    thr = opts.get("thresholds", {}) or {}
    vb = opts.get("voicebm", {}) or {}
    active_opts = opts.get("active", {}) or {}

    cfg = {
        "mqtt": {
            "broker": mqtt_broker,
            "port": mqtt_port,
            "user": mqtt_user,
            "password": mqtt_pass,
        },
        "hosts": {
            "home_assistant": "homeassistant",
            "voicebm_host": public_host,
        },
        "paths": {
            "voicebm_base": VOICEBM_BASE,
            "sherpa_bin": SHERPA_BIN,
            "sherpa_model": SHERPA_MODEL,
            "conda_path": "",
            "python_bin": "/usr/bin/python3",
        },
        "environment": {
            "type": "system",
            "conda_path": "",
            "env_name": "",
            "venv_path": "",
            "python_bin": "/usr/bin/python3",
        },
        "audio_server": {
            "host": "0.0.0.0",
            "port": 9090,
            "base_url": f"http://{public_host}:9090",
        },
        "components": {
            "active": bool(comp.get("active", True)),
            "passive": bool(comp.get("passive", False)),
            "ambient": bool(comp.get("ambient", False)),
            "emote": bool(comp.get("emote", False)),
        },
        "nodes": {},
        "thresholds": {
            "passive": float(thr.get("passive", 0.22)),
            "active": float(thr.get("active", 0.50)),
        },
    }

    for node in opts.get("nodes", []) or []:
        node_id = (node.get("node_id") or "").strip()
        if not node_id or not node.get("rtsp_url"):
            continue
        entry = {
            "friendly_name": node.get("friendly_name") or node_id,
            "rtsp_url": node["rtsp_url"],
            "audio_filter": node.get("audio_filter", ""),
        }
        if node.get("recorder_enabled"):
            entry["recorder_enabled"] = True
        if node.get("ambient_enabled"):
            entry["ambient_enabled"] = True
        cfg["nodes"][node_id] = entry

    if cfg["components"]["active"]:
        cfg["voicebm"] = {
            "gallery_max": int(vb.get("gallery_max", 75)),
            "current_lead_trim_ms": int(vb.get("active_lead_trim_ms", 0)),
            "inject_identity": bool(vb.get("inject_identity", True)),
            "transcript_preferred": bool(vb.get("transcript_preferred", True)),
        }
        # Informational only — nothing in the vendored engine reads this back;
        # the bundled ASR service (voicebm-wyoming-asr) reads these same
        # option values directly from bashio at its own startup.
        def _clean(v, default=""):
            # dropdown values carry a display annotation: "value (example use)"
            v = (v or default).split(" (")[0].strip()
            return "" if v == "none" else v

        cfg["active"] = {
            "model_en": _clean(active_opts.get("model_en")),
            "model_multilingual": _clean(active_opts.get("model_multilingual")),
            "quantization": _clean(active_opts.get("quantization")),
            "device": _clean(active_opts.get("device"), "cpu") or "cpu",
        }

    if cfg["components"]["passive"]:
        cfg["vad"] = {"speech_threshold": 0.6, "min_speech_ratio": 0.5, "min_speech_duration": 0.8}

    if cfg["components"]["ambient"]:
        cfg["thresholds"]["ambient_context"] = float(thr.get("ambient_context", 0.18))
        cfg["thresholds"]["ambient_margin"] = float(thr.get("ambient_margin", 0.05))
        cfg["ambient"] = {"cycle_s": 30, "mode": "attention", "ping_timeout_s": 5}

    if cfg["components"]["emote"]:
        cfg["emote"] = {"ser_script": f"{VOICEBM_BASE}/bin/ser_infer.sh", "ser_timeout_s": 60}

    os.makedirs(os.path.dirname(CONFIG_OUT), exist_ok=True)
    tmp = CONFIG_OUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_OUT)
    print(f"wrote {CONFIG_OUT}")


if __name__ == "__main__":
    main()
