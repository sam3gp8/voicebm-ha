#!/usr/bin/env python3
"""
render_asr_handler.py — fills VoiceBM's handler.py.template with this add-on's
MQTT settings and writes it over the bundled wyoming_onnx_asr package's own
handler.py, in place, in this same container's site-packages.

Upstream VoiceBM ships this as scripts/deploy_handler.sh, which docker-cp's
the rendered file into a SEPARATE, externally-managed ASR container and
restarts it. That's not available (or needed) here — the ASR server is
vendored into this same image and runs as another supervised process, so
"deploying" the handler is just overwriting one file before that process
starts.
"""
import importlib.util
import json
import sys

CONFIG = "/share/voicebm/config.json"
TEMPLATE = "/home/user/voicebm/templates/active/handler.py.template"


def main():
    spec = importlib.util.find_spec("wyoming_onnx_asr")
    if spec is None or not spec.submodule_search_locations:
        print("wyoming_onnx_asr package not found — was it installed at build time?", file=sys.stderr)
        sys.exit(1)
    pkg_dir = list(spec.submodule_search_locations)[0]
    dest = f"{pkg_dir}/handler.py"

    with open(CONFIG) as f:
        mqtt = json.load(f).get("mqtt", {})

    with open(TEMPLATE) as f:
        rendered = f.read()

    fills = {
        "@@MQTT_BROKER@@": str(mqtt.get("broker", "")),
        "@@MQTT_PORT@@": str(mqtt.get("port", 1883)),
        "@@MQTT_USER@@": str(mqtt.get("user", "")),
        "@@MQTT_PASS@@": str(mqtt.get("password", "")),
    }
    for k, v in fills.items():
        rendered = rendered.replace(k, v)
    assert "@@MQTT_" not in rendered, "unfilled MQTT placeholder remains in rendered handler.py"

    with open(dest, "w") as f:
        f.write(rendered)
    print(f"rendered handler.py -> {dest}")


if __name__ == "__main__":
    main()
