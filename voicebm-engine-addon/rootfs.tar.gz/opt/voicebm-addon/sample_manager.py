#!/usr/bin/env python3
"""
sample_manager.py — per-sample gallery management over MQTT.

VoiceBM's engine can delete a whole enrolled identity, and it auto-trims the
oldest samples past gallery_max, but it has no way to delete ONE specific
sample. That matters when a gallery accidentally captured a TV/music voice, a
visitor, or background noise: you want to prune that one bad sample without
throwing away the real person's other samples.

This is a small standalone service (it does NOT modify any vendored engine
file). It subscribes to two request topics and answers on response topics:

  voicebm/samples/list_request   {person_id}
      -> voicebm/samples/list_response
         {person_id, display_name, samples:[{event_id, enrolled_at, source,
          recording_url}]}

  voicebm/samples/delete_request {person_id, event_ids:[...]}
      -> voicebm/samples/delete_response {person_id, deleted, remaining, ok}

A sample is deleted by removing its on-disk embedding (.txt) and recording
(.wav) and dropping it from the person's metadata.json. Because the running STT
service computes each person's centroid from the embedding .txt files and only
reloads its in-memory gallery inside its own handlers, this service restarts
the STT service (s6-svc) after a delete so the change takes effect live. A
restart is a ~1s blip and sample-pruning is a deliberate, infrequent action, so
that's an acceptable trade for not modifying vendored engine code. If the whole
gallery for a person becomes empty, the person directory is removed.

Runs only when the 'active' component is enabled (same gate as the rest).
"""
import glob
import json
import os
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/user/voicebm")
sys.path.insert(0, "/home/user/voicebm/bin")

import paho.mqtt.client as mqtt  # noqa: E402
from voicebm_config import get_mqtt_config  # noqa: E402

ENROLL_DIR = Path("/home/user/voicebm/enroll")
STT_SERVICE_DIR = "/run/service/voicebm-stt"  # s6-overlay v3 supervision dir

LIST_REQ = "voicebm/samples/list_request"
LIST_RES = "voicebm/samples/list_response"
DEL_REQ = "voicebm/samples/delete_request"
DEL_RES = "voicebm/samples/delete_response"

# Audio server (bundled) serves per-person recordings; used to build a
# playback URL so the user can hear a sample before pruning it.
AUDIO_PORT = int(os.environ.get("VBM_AUDIO_PORT", "9090"))


def log(m):
    print(f"[sample_manager] {m}", flush=True)


def _read_meta(pid: str):
    md = ENROLL_DIR / pid / "metadata.json"
    if not md.is_file():
        return None
    try:
        return json.loads(md.read_text())
    except Exception:
        return None


def _write_meta(pid: str, meta: dict):
    md = ENROLL_DIR / pid / "metadata.json"
    meta["total_samples"] = len(meta.get("samples", []))
    tmp = md.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(meta, indent=2))
    tmp.replace(md)


def _list_samples(pid: str) -> dict:
    meta = _read_meta(pid)
    person_dir = ENROLL_DIR / pid
    display = pid.replace("_", " ").title()
    out = []
    if meta:
        display = meta.get("display_name", display)
        for s in meta.get("samples", []):
            eid = s.get("event_id") or Path(s.get("embedding", "")).stem
            rec = s.get("recording", "")
            out.append(
                {
                    "event_id": eid,
                    "enrolled_at": s.get("enrolled_at", ""),
                    "source": s.get("source", ""),
                    # audio_server serves /<person_id>/recordings/<file> style paths
                    "recording_url": f"{rec}" if rec else "",
                }
            )
    else:
        # metadata missing — fall back to raw embedding files on disk
        emb_dir = person_dir / "embeddings"
        if emb_dir.is_dir():
            for f in sorted(emb_dir.glob("*.txt")):
                out.append({"event_id": f.stem, "enrolled_at": "", "source": "", "recording_url": ""})
    return {"person_id": pid, "display_name": display, "samples": out}


def _delete_samples(pid: str, event_ids: list) -> dict:
    person_dir = ENROLL_DIR / pid
    meta = _read_meta(pid)
    want = set(event_ids)
    deleted = 0

    if meta:
        keep = []
        for s in meta.get("samples", []):
            eid = s.get("event_id") or Path(s.get("embedding", "")).stem
            if eid in want:
                for rel_key in ("embedding", "recording"):
                    rel = s.get(rel_key)
                    if rel:
                        p = person_dir / rel
                        try:
                            if p.is_file():
                                p.unlink()
                        except Exception as e:
                            log(f"could not remove {p}: {e}")
                # also remove any stray files matching the event id
                deleted += 1
            else:
                keep.append(s)
        meta["samples"] = keep
        _write_meta(pid, meta)
    else:
        # no metadata — delete embedding/recording files by id directly
        for eid in want:
            for pat in (
                person_dir / "embeddings" / f"{eid}.txt",
                person_dir / "recordings" / f"{eid}.wav",
            ):
                try:
                    if pat.is_file():
                        pat.unlink()
                        if pat.suffix == ".txt":
                            deleted += 1
                except Exception as e:
                    log(f"could not remove {pat}: {e}")

    # Belt-and-suspenders: ensure no orphan embedding .txt remains for a deleted id
    for eid in want:
        for f in glob.glob(str(person_dir / "embeddings" / f"{eid}*.txt")):
            try:
                os.unlink(f)
            except Exception:
                pass

    remaining = len(list((person_dir / "embeddings").glob("*.txt"))) if (person_dir / "embeddings").is_dir() else 0

    # If nothing is left, remove the whole (now-empty) identity.
    if remaining == 0:
        try:
            shutil.rmtree(person_dir, ignore_errors=True)
            log(f"'{pid}' had no samples left — removed the identity")
        except Exception as e:
            log(f"could not remove empty identity {pid}: {e}")

    # Restart the STT service so it reloads the gallery from disk (its
    # in-memory centroids only refresh inside its own handlers).
    _restart_stt_service()

    return {"person_id": pid, "deleted": deleted, "remaining": remaining, "ok": True}


def _restart_stt_service():
    """Ask s6 to restart the identity (STT) service so the gallery reloads.
    Best-effort: if s6-svc isn't reachable, the change still applies on the
    next natural reload (enroll) or add-on restart."""
    import subprocess

    if not os.path.isdir(STT_SERVICE_DIR):
        log(f"STT service dir {STT_SERVICE_DIR} not found — skipping restart "
            f"(gallery reloads on next enroll/restart)")
        return
    try:
        subprocess.run(["s6-svc", "-r", STT_SERVICE_DIR], check=False, timeout=10)
        log("requested STT service restart to reload gallery")
    except Exception as e:
        log(f"could not restart STT service ({e}); gallery reloads later")


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        client.subscribe([(LIST_REQ, 1), (DEL_REQ, 1)])
        log(f"listening on {LIST_REQ} and {DEL_REQ}")
    else:
        log(f"MQTT connect failed rc={rc}")


def on_message(client, userdata, msg):
    try:
        data = json.loads(msg.payload.decode("utf-8"))
    except Exception:
        log("bad payload — ignored")
        return
    pid = (data.get("person_id") or "").strip()
    if not pid or "/" in pid or ".." in pid:
        return

    if msg.topic == LIST_REQ:
        client.publish(LIST_RES, json.dumps(_list_samples(pid)), qos=1)
    elif msg.topic == DEL_REQ:
        eids = data.get("event_ids") or []
        result = _delete_samples(pid, [str(e) for e in eids])
        client.publish(DEL_RES, json.dumps(result), qos=1)
        log(f"deleted {result['deleted']} sample(s) from '{pid}', {result['remaining']} remain")


def main():
    cfg = get_mqtt_config()
    client = mqtt.Client()
    if cfg.get("user"):
        client.username_pw_set(cfg["user"], cfg.get("password", ""))
    client.on_connect = on_connect
    client.on_message = on_message
    for _ in range(30):
        try:
            client.connect(cfg["broker"], int(cfg["port"]), 60)
            break
        except Exception as e:
            log(f"MQTT retry ({e})")
            time.sleep(2)
    else:
        log("MQTT unreachable — exiting so s6 restarts us")
        sys.exit(1)
    client.loop_forever()


if __name__ == "__main__":
    main()
