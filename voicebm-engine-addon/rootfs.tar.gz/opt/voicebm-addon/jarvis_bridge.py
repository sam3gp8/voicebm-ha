#!/usr/bin/env python3
"""
jarvis_bridge.py — labelled hands-free enrollment driven by JARVIS-AIO.

JARVIS-AIO (github.com/sam3gp8/jarvis-aio) already consumes VoiceBM's identity
directly: it reads the per-person ``binary_sensor.<person>_voice`` entities
VoiceBM publishes and feeds them into its identity resolver's voice tier. That
half needs no code here — just point JARVIS's ``voice_recognition_source`` at
``binary_sensor.*_voice``.

The half worth automating is *enrollment*. When JARVIS is confident who is
speaking from its OTHER signals (sole occupant, a recent camera face match) but
VoiceBM doesn't recognise that voice yet, JARVIS fires a
``jarvis_voice_enroll_candidate`` event carrying the CORRECT person name — a
labelled enrollment opportunity. That's strictly better than VoiceBM's blind
auto-enroller (which can only invent "Speaker N"): here the name is known.

To close the loop, the JARVIS side publishes that person to an MQTT topic (a
one-line HA automation: on ``jarvis_voice_enroll_candidate`` ->
``mqtt.publish`` topic ``voicebm/jarvis/enroll_current`` payload
``{"display_name": "{{ trigger.event.data.person }}"}``). This bridge listens
on that topic and enrolls VoiceBM's most-recent pending voice under that name,
reusing the same ``voicebm/pending_active/enroll`` command the dashboard uses —
so no vendored VoiceBM code is touched.

Enabled by AUTO_ENROLL / jarvis bridge option; safe no-op when disabled.
"""
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/user/voicebm")

import paho.mqtt.client as mqtt  # noqa: E402
from voicebm_config import get_mqtt_config  # noqa: E402

PENDING_JSON = Path("/home/user/voicebm/pending_active/pending.json")
ENROLL_TOPIC = "voicebm/pending_active/enroll"

# Topic JARVIS publishes the confident person name to. Kept configurable in
# case the user wires a different one, but this default matches the docs.
LISTEN_TOPIC = os.environ.get("JARVIS_ENROLL_TOPIC", "voicebm/jarvis/enroll_current")
ENABLED = os.environ.get("JARVIS_BRIDGE_ENABLED", "false").lower() == "true"
# Only accept an enroll whose newest pending voice is fresher than this (s),
# so a stale pending entry isn't labelled with a name from a later utterance.
MAX_PENDING_AGE = float(os.environ.get("JARVIS_ENROLL_MAX_AGE", "30"))
# How long to wait for the engine to finish embedding and surface the pending
# entry after JARVIS's candidate event (covers the embed latency race).
PENDING_APPEAR_WAIT = float(os.environ.get("JARVIS_PENDING_APPEAR_WAIT", "10"))


def log(msg):
    print(f"[jarvis_bridge] {msg}", flush=True)


def newest_pending():
    """Return the freshest pending entry (by timestamp), or None."""
    try:
        buf = json.loads(PENDING_JSON.read_text())
    except Exception:
        return None
    if not buf:
        return None
    # entries carry a float 'timestamp'; newest wins
    try:
        return max(buf, key=lambda e: e.get("timestamp", 0))
    except Exception:
        return buf[-1]


def on_connect(client, userdata, flags, rc):
    if rc == 0:
        client.subscribe(LISTEN_TOPIC, qos=1)
        log(f"listening on {LISTEN_TOPIC}")
    else:
        log(f"MQTT connect failed rc={rc}")


def on_message(client, userdata, msg):
    try:
        data = json.loads(msg.payload.decode("utf-8"))
    except Exception:
        # allow a bare name payload too
        data = {"display_name": msg.payload.decode("utf-8", "ignore").strip()}

    display_name = (data.get("display_name") or "").strip()
    if not display_name:
        log("enroll request with no display_name — ignored")
        return

    # JARVIS typically fires its candidate the moment speech happens, but the
    # engine needs a moment to embed the audio before a pending entry exists.
    # Poll briefly for a FRESH entry instead of giving up instantly (racing
    # this window was observed live: "no pending voice is waiting" while the
    # entry landed moments later, unlabeled).
    arrived_at = time.time()
    entry = None
    deadline = arrived_at + PENDING_APPEAR_WAIT
    while time.time() < deadline:
        cand = newest_pending()
        if cand and float(cand.get("timestamp", 0)) >= arrived_at - MAX_PENDING_AGE:
            entry = cand
            break
        time.sleep(0.25)

    if not entry:
        log(f"JARVIS asked to enroll '{display_name}' but no pending voice appeared "
            f"within {PENDING_APPEAR_WAIT:.0f}s — ignored (is the identity pipeline flowing?)")
        return

    age = time.time() - float(entry.get("timestamp", 0))
    if age > MAX_PENDING_AGE + PENDING_APPEAR_WAIT:
        log(f"newest pending voice is {age:.0f}s old — not labelling it '{display_name}'")
        return

    person_id = display_name.lower().replace(" ", "_")
    payload = json.dumps({
        "id": entry["id"],
        "person_id": person_id,
        "display_name": display_name,
    })
    client.publish(ENROLL_TOPIC, payload, qos=1)
    log(f"enrolled pending {entry['id']} as '{display_name}' (JARVIS-labelled, age {age:.0f}s)")


def main():
    if not ENABLED:
        log("disabled (jarvis bridge off) — idle")
        while True:
            time.sleep(3600)

    log(f"enabled — bridging {LISTEN_TOPIC} -> {ENROLL_TOPIC}")
    cfg = get_mqtt_config()
    client = mqtt.Client()
    if cfg.get("user"):
        client.username_pw_set(cfg["user"], cfg.get("password", ""))
    client.on_connect = on_connect
    client.on_message = on_message

    for _ in range(30):
        try:
            client.connect(cfg["broker"], int(cfg["port"]), 60)
            break
        except Exception as e:
            log(f"MQTT connect retry ({e})")
            time.sleep(2)
    else:
        log("could not reach MQTT broker — exiting so s6 restarts us")
        sys.exit(1)

    client.loop_forever()


if __name__ == "__main__":
    main()
