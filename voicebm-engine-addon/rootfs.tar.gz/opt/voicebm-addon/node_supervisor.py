#!/usr/bin/env python3
"""
node_supervisor.py — runs rec_node.sh / embed_node.sh / publish_identity_node.py
for every node in config.json that has recorder_enabled=true.

Upstream (scripts/replicate_node.sh) writes three systemd units per node
(voicebm-recorder-{node}, voicebm-embedder-{node}, voicebm-publisher-{node})
each with Restart=always. Since the add-on is one container, this does the
same job as one supervising process instead of N*3 systemd units: it starts
the trio for every configured node, and restarts any that exit, with the
same RestartSec backoff upstream's units used (2s recorder/embedder, 5s
publisher).

Re-reads config.json every cycle, so adding/removing nodes just needs an
add-on restart (which regenerates config.json from the new options).
"""
import json
import os
import signal
import subprocess
import sys
import time

CONFIG = "/home/user/voicebm/config.json"
BIN = "/home/user/voicebm/bin"

PYTHON = sys.executable or "/usr/bin/python3"

RESTART_SEC = {"recorder": 2, "embedder": 2, "publisher": 5}

procs = {}   # key -> Popen
next_restart = {}  # key -> earliest epoch to (re)start


def load_nodes():
    try:
        with open(CONFIG) as f:
            cfg = json.load(f)
    except Exception as e:
        print(f"[node_supervisor] failed to read {CONFIG}: {e}", file=sys.stderr)
        return {}
    nodes = cfg.get("nodes", {}) or {}
    return {nid: n for nid, n in nodes.items() if n.get("recorder_enabled")}


def cmd_for(role, node_id):
    if role == "recorder":
        return ["/usr/bin/env", "bash", f"{BIN}/rec_node.sh", node_id]
    if role == "embedder":
        return ["/usr/bin/env", "bash", f"{BIN}/embed_node.sh", node_id]
    if role == "publisher":
        env = os.environ.copy()
        env["PYTHONNOUSERSITE"] = "1"
        return [PYTHON, f"{BIN}/publish_identity_node.py", node_id]
    raise ValueError(role)


def ensure_started(key, role, node_id):
    p = procs.get(key)
    if p is not None and p.poll() is None:
        return  # already running
    if p is not None:
        rc = p.returncode
        print(f"[node_supervisor] {key} exited (rc={rc}) — restarting in {RESTART_SEC[role]}s")
    now = time.monotonic()
    if next_restart.get(key, 0) > now:
        return
    print(f"[node_supervisor] starting {key}")
    procs[key] = subprocess.Popen(cmd_for(role, node_id))
    next_restart[key] = now + RESTART_SEC[role]


def stop_key(key):
    p = procs.pop(key, None)
    if p and p.poll() is None:
        p.terminate()
        try:
            p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            p.kill()


_running = True


def _sigterm(*_):
    global _running
    _running = False


signal.signal(signal.SIGTERM, _sigterm)
signal.signal(signal.SIGINT, _sigterm)


def main():
    print("[node_supervisor] starting")
    while _running:
        active_nodes = load_nodes()
        wanted_keys = set()
        for node_id in active_nodes:
            for role in ("recorder", "embedder", "publisher"):
                key = f"{role}:{node_id}"
                wanted_keys.add(key)
                ensure_started(key, role, node_id)

        # stop anything for nodes that were removed from config
        for key in list(procs.keys()):
            if key not in wanted_keys:
                print(f"[node_supervisor] node removed from config — stopping {key}")
                stop_key(key)

        time.sleep(3)

    print("[node_supervisor] shutting down")
    for key in list(procs.keys()):
        stop_key(key)


if __name__ == "__main__":
    main()
