#!/usr/bin/env bash
# Source this from an s6 longrun `run` script before the final `exec`:
#   . /opt/voicebm-addon/require_component.sh active
#   . /opt/voicebm-addon/require_component.sh passive torch   # 2nd arg = required py module
# If the named component is disabled in config.json, this parks the service
# with `exec sleep infinity` (s6 sees it as "up" but it does nothing and
# costs ~0 resources) instead of exec'ing the real program. This avoids
# needing conditional s6-rc bundles for every combination of toggles — the
# add-on's option toggles are re-read from config.json on every restart.
#
# Optional 2nd arg: a python module the service needs (e.g. torch for VAD,
# funasr for emote). Those are OPTIONAL build stacks (INCLUDE_PASSIVE_VAD /
# INCLUDE_EMOTE, off by default). If the component is enabled but the module
# wasn't built into the image, idle with a clear message instead of letting
# the service crash-loop — the user needs to rebuild with the right build arg.
COMPONENT="$1"
REQUIRED_MODULE="${2:-}"
CONFIG=/share/voicebm/config.json

enabled="false"
if [[ -f "$CONFIG" ]]; then
  enabled=$(python3 -c "
import json
try:
    c = json.load(open('$CONFIG'))
    print('true' if c.get('components', {}).get('$COMPONENT') else 'false')
except Exception:
    print('false')
")
fi

if [[ "$enabled" != "true" ]]; then
  echo "[$(basename "$0")] component '$COMPONENT' disabled in add-on options — idle."
  exec sleep infinity
fi

if [[ -n "$REQUIRED_MODULE" ]]; then
  if ! python3 -c "import ${REQUIRED_MODULE}" 2>/dev/null; then
    echo "[$(basename "$0")] component '$COMPONENT' is enabled, but its required dependency '${REQUIRED_MODULE}' is not in this image."
    echo "[$(basename "$0")] This is an optional stack that's off by default. Rebuild the add-on with the matching build arg"
    echo "[$(basename "$0")] (INCLUDE_PASSIVE_VAD=true for passive/VAD, INCLUDE_EMOTE=true for emote) to enable it. Idling."
    exec sleep infinity
  fi
fi
