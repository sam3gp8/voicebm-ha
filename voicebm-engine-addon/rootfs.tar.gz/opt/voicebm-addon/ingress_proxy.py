#!/usr/bin/env python3
"""
ingress_proxy.py — makes VoiceBM's dashboard work under Home Assistant Ingress
(sidebar panel, authenticated by HA, no open port) WITHOUT editing the vendored
dashboard.

Why a proxy is needed: the vendored dashboard (voicebm_dashboard.py) issues
absolute fetches like `fetch('/api/state/pending')` and loads assets from
absolute paths. Under Ingress the app is served beneath a per-session prefix
(`/api/hassio_ingress/<token>/`), so absolute `/api/...` requests escape the
prefix and 404. Since the dashboard HTML/JS is upstream code we don't modify,
this proxy rewrites those absolute paths to be relative on the way out.

Flow:  HA Ingress  ->  this proxy (:8099)  ->  real dashboard (:5000)

- GET of the HTML page: fetch from the real dashboard, rewrite `fetch('/api/`
  -> `fetch('api/` (relative), and normalize a couple of asset roots, then
  serve. Relative URLs resolve against the Ingress base automatically.
- Everything else (the /api/* XHRs, now arriving relative-resolved under the
  prefix, and any assets): transparently proxied through to :5000.

This is deliberately tiny and dependency-light (Flask + requests, already in
the image). It does not touch auth — HA Ingress handles that in front of us.
"""
import logging

import requests
from flask import Flask, Response, request

UPSTREAM = "http://127.0.0.1:5000"
INGRESS_PORT = 8099

logging.basicConfig(level=logging.INFO, format="[ingress_proxy] %(message)s")
log = logging.getLogger("ingress_proxy")

app = Flask(__name__)

# Hop-by-hop headers we must not forward.
_HOP = {
    "content-encoding", "content-length", "transfer-encoding", "connection",
    "keep-alive", "proxy-authenticate", "proxy-authorization", "te",
    "trailers", "upgrade",
}


def _rewrite_html(text: str) -> str:
    """Make the dashboard's absolute paths Ingress-relative."""
    # fetch('/api/...  ->  fetch('api/...   (single or double quotes)
    text = text.replace("fetch('/api/", "fetch('api/")
    text = text.replace('fetch("/api/', 'fetch("api/')
    # Any other absolute API refs used in fetch options / strings
    text = text.replace("'/api/", "'api/").replace('"/api/', '"api/')
    # A <base> tag makes every remaining relative URL resolve under the Ingress
    # prefix. HA passes the ingress path in the X-Ingress-Path header.
    ingress_path = request.headers.get("X-Ingress-Path", "")
    if ingress_path and "<head>" in text and "<base " not in text:
        base = ingress_path.rstrip("/") + "/"
        text = text.replace("<head>", f'<head><base href="{base}">', 1)
    return text


@app.route("/", defaults={"path": ""},
           methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
@app.route("/<path:path>",
           methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
def proxy(path):
    url = f"{UPSTREAM}/{path}"
    try:
        upstream = requests.request(
            method=request.method,
            url=url,
            params=request.args,
            data=request.get_data(),
            headers={k: v for k, v in request.headers if k.lower() != "host"},
            cookies=request.cookies,
            allow_redirects=False,
            timeout=30,
        )
    except requests.RequestException as exc:
        return Response(f"VoiceBM dashboard not reachable: {exc}", status=502)

    ctype = upstream.headers.get("Content-Type", "")
    body = upstream.content
    # Only rewrite the HTML document; leave JSON/assets untouched.
    if "text/html" in ctype:
        body = _rewrite_html(upstream.text).encode("utf-8")

    headers = [(k, v) for k, v in upstream.headers.items()
               if k.lower() not in _HOP]
    return Response(body, status=upstream.status_code, headers=headers)


if __name__ == "__main__":
    log.info(f"proxying HA Ingress :{INGRESS_PORT} -> dashboard {UPSTREAM}")
    app.run(host="0.0.0.0", port=INGRESS_PORT)
