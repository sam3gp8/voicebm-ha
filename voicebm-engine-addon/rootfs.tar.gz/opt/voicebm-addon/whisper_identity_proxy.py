#!/usr/bin/env python3
"""
whisper_identity_proxy.py — use the existing HAOS Whisper add-on for
transcription while VoiceBM still identifies the speaker, for setups with a
Voice PE / ESPHome satellite (no room mic to tap).

WHY THIS EXISTS
An Assist pipeline sends its audio to exactly ONE speech-to-text engine.
VoiceBM normally *is* that engine so it can identify the speaker on the same
audio it transcribes. But you already run Whisper on HAOS and don't want a
second transcriber. VoiceBM's identity engine, however, is driven by a simple,
transcription-independent MQTT request (publish {request_id, audio_path} to
voicebm/stt/analyze_request; its STT service embeds the WAV, matches the
gallery, and publishes current_speaker / binary_sensor.<person>_voice). So we
don't need VoiceBM to transcribe at all.

This proxy is the single STT Assist talks to. For each utterance it:
  1. streams the audio through to the EXTERNAL Whisper Wyoming add-on and
     returns Whisper's transcript to Assist (Whisper is the only transcriber);
  2. writes the same utterance WAV where VoiceBM's identity engine reads it and
     publishes voicebm/stt/analyze_request, so VoiceBM identifies the speaker
     in parallel and publishes identity over MQTT for JARVIS / Ollama to use.

VoiceBM's own bundled ASR (voicebm-wyoming-asr) is disabled in this mode — the
identity engine (STT service, embedder, publishers) is all that runs. No fork
of VoiceBM's vendored handler; this is a separate, thin component.

Env (from the add-on run script):
  WHISPER_URI            tcp://<host>:<port> of the HAOS Whisper add-on
  PROXY_PORT             port Assist connects to (default 10400)
  VB_SHARED_AUDIO_DIR    where to drop WAVs for VoiceBM (default the shared dir)
  IDENTITY_INJECT        "true" to prepend "<name>: " to Whisper's text
  IDENTITY_WAIT_MS       ms to wait for the identity verdict if injecting
  MQTT_* / from config.json for the broker
"""
import asyncio
import json
import os
import sys
import time
import uuid
import wave

sys.path.insert(0, "/home/user/voicebm")

import paho.mqtt.client as mqtt  # noqa: E402
from voicebm_config import get_mqtt_config  # noqa: E402

from wyoming.asr import Transcript  # noqa: E402
from wyoming.audio import AudioChunk, AudioStart, AudioStop  # noqa: E402
from wyoming.client import AsyncClient  # noqa: E402
from wyoming.event import Event  # noqa: E402
from wyoming.info import Describe, Info, AsrModel, AsrProgram, Attribution  # noqa: E402
from wyoming.server import AsyncServer, AsyncEventHandler  # noqa: E402

WHISPER_URI = os.environ.get("WHISPER_URI", "tcp://127.0.0.1:10301")
PROXY_PORT = int(os.environ.get("PROXY_PORT", "10400"))
SHARED_AUDIO_DIR = os.environ.get("VB_SHARED_AUDIO_DIR", "/home/user/voicebm/stt_requests")
IDENTITY_INJECT = os.environ.get("IDENTITY_INJECT", "false").lower() == "true"
IDENTITY_WAIT_MS = int(os.environ.get("IDENTITY_WAIT_MS", "1200"))

VB_REQUEST_TOPIC = "voicebm/stt/analyze_request"
ACTIVE_SPEAKER_TOPIC = "voicebm/active_speaker"

# ---- shared MQTT (identity request out; active_speaker in for optional inject)
_mqtt = None
_last_active = {"name": None, "ts": 0.0}


def _log(m):
    print(f"[whisper_identity_proxy] {m}", flush=True)


def _mqtt_connect():
    global _mqtt
    cfg = get_mqtt_config()
    c = mqtt.Client()
    if cfg.get("user"):
        c.username_pw_set(cfg["user"], cfg.get("password", ""))

    def on_connect(cl, u, f, rc):
        cl.subscribe(ACTIVE_SPEAKER_TOPIC, qos=1)

    def on_message(cl, u, msg):
        _last_active["name"] = msg.payload.decode("utf-8", "ignore")
        _last_active["ts"] = time.time()

    c.on_connect = on_connect
    c.on_message = on_message
    for _ in range(30):
        try:
            c.connect(cfg["broker"], int(cfg["port"]), 60)
            break
        except Exception as e:
            _log(f"MQTT retry ({e})")
            time.sleep(2)
    else:
        _log("MQTT unreachable; identity requests will fail")
    c.loop_start()
    _mqtt = c


def _publish_identity_request(audio_path):
    if _mqtt is None:
        return
    payload = {"request_id": str(uuid.uuid4()), "audio_path": audio_path, "timestamp": time.time()}
    _mqtt.publish(VB_REQUEST_TOPIC, json.dumps(payload), qos=1)
    _log(f"identity request published for {os.path.basename(audio_path)}")


class ProxyHandler(AsyncEventHandler):
    """One per Assist connection. Forwards to Whisper, tees audio to VoiceBM."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._whisper = None
        self._wav = None
        self._wav_path = None
        self._rate = 16000
        self._width = 2
        self._channels = 1
        self._utt_start = 0.0

    async def _ensure_whisper(self):
        if self._whisper is None:
            self._whisper = AsyncClient.from_uri(WHISPER_URI)
            await self._whisper.connect()

    async def handle_event(self, event: Event) -> bool:
        # Answer capability discovery ourselves (advertise as an ASR service).
        if Describe.is_type(event.type):
            info = Info(asr=[AsrProgram(
                name="voicebm-whisper-identity-proxy",
                description="HAOS Whisper transcription + VoiceBM speaker identity",
                attribution=Attribution(name="VoiceBM add-on", url="https://github.com/cybericebyte/VoiceBM"),
                installed=True,
                version="1.0.0",
                models=[AsrModel(
                    name="whisper-via-haos",
                    description="Transcription delegated to the HAOS Whisper add-on",
                    attribution=Attribution(name="Whisper", url="https://github.com/openai/whisper"),
                    installed=True, languages=[], version=None,
                )],
            )])
            await self.write_event(info.event())
            return True

        await self._ensure_whisper()

        if AudioStart.is_type(event.type):
            a = AudioStart.from_event(event)
            self._rate, self._width, self._channels = a.rate, a.width, a.channels
            self._utt_start = time.time()
            fname = f"stt_{int(time.time()*1000)}.wav"
            self._wav_path = os.path.join(SHARED_AUDIO_DIR, fname)
            os.makedirs(SHARED_AUDIO_DIR, exist_ok=True)
            self._wav = wave.open(self._wav_path, "wb")
            self._wav.setframerate(a.rate)
            self._wav.setsampwidth(a.width)
            self._wav.setnchannels(a.channels)
            await self._whisper.write_event(event)
            return True

        if AudioChunk.is_type(event.type):
            chunk = AudioChunk.from_event(event)
            if self._wav is not None:
                self._wav.writeframes(chunk.audio)
            await self._whisper.write_event(event)   # forward to Whisper
            return True

        if AudioStop.is_type(event.type):
            if self._wav is not None:
                self._wav.close()
                self._wav = None
                # Kick off VoiceBM identity on the captured utterance.
                _publish_identity_request(self._wav_path)
            await self._whisper.write_event(event)   # tell Whisper to transcribe

            # Read Whisper's transcript and return it to Assist.
            text = ""
            while True:
                resp = await self._whisper.read_event()
                if resp is None:
                    break
                if Transcript.is_type(resp.type):
                    text = Transcript.from_event(resp).text
                    break

            if IDENTITY_INJECT:
                name = self._fresh_identity()
                if name:
                    text = f"{name}: {text}"

            await self.write_event(Transcript(text=text).event())
            await self._disconnect_whisper()
            return True

        # Pass through anything else (e.g. Transcribe language hints).
        await self._whisper.write_event(event)
        return True

    def _fresh_identity(self):
        # Wait briefly for VoiceBM's verdict (published to active_speaker).
        deadline = time.time() + (IDENTITY_WAIT_MS / 1000.0)
        while time.time() < deadline:
            if _last_active["ts"] >= self._utt_start:
                n = _last_active["name"]
                if n and n not in ("user", "none", "unknown", "unavailable", ""):
                    return n
                return None
            time.sleep(0.05)
        return None

    async def _disconnect_whisper(self):
        try:
            if self._whisper is not None:
                await self._whisper.disconnect()
        except Exception:
            pass
        self._whisper = None


async def main():
    _mqtt_connect()
    _log(f"listening on tcp://0.0.0.0:{PROXY_PORT} -> Whisper {WHISPER_URI} "
         f"(identity_inject={IDENTITY_INJECT})")
    server = AsyncServer.from_uri(f"tcp://0.0.0.0:{PROXY_PORT}")
    await server.run(ProxyHandler)


if __name__ == "__main__":
    asyncio.run(main())
