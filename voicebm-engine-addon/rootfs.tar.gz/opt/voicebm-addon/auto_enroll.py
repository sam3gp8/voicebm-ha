#!/usr/bin/env python3
"""
auto_enroll.py — optional automatic enrollment for VoiceBM.

VoiceBM normally enrolls a speaker only when a human opens the dashboard,
listens to a pending clip, and types a name. This process automates that
*conservatively*, reusing VoiceBM's own machinery so it behaves exactly like
a careful human would:

  - It uses VoiceBM's own `voice_clustering` module to group unrecognized
    utterances by voiceprint similarity (NOT raw per-utterance pending
    entries — those would enroll every stranger/TV voice as a new person).
  - It only auto-enrolls a cluster that:
      * has at least AUTO_ENROLL_MIN_SAMPLES samples (enough to be a real,
        recurring speaker rather than a one-off), AND
      * is internally tight — avg intra-cluster similarity >=
        AUTO_ENROLL_MIN_COHESION (guards against a loose blob of different
        people getting merged), AND
      * is NOT already a likely match for an enrolled person (VoiceBM's
        find_likely_person_match, so it doesn't create a duplicate identity
        for someone already enrolled).
  - It enrolls by publishing the SAME `voicebm/pending_active/enroll` MQTT
    command the dashboard publishes, per cluster member — the engine's
    handle_pending_enroll does the real work. No vendored code is modified.

Auto-assigned names are AUTO_ENROLL_PREFIX + N (e.g. "Speaker 1"). Rename
them later from the dashboard / the HA device; the voiceprints are what
matter, the label is cosmetic.

Everything is driven by env vars set from the add-on options by the s6 run
script. Disabled unless AUTO_ENROLL_ENABLED=true.
"""
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, "/home/user/voicebm")
sys.path.insert(0, "/home/user/voicebm/bin")

import paho.mqtt.client as mqtt  # noqa: E402
from voicebm_config import get_mqtt_config  # noqa: E402

# voice_clustering lives in bin/ and expects to be importable by name
import voice_clustering  # noqa: E402

ENROLL_TOPIC = "voicebm/pending_active/enroll"
PENDING_JSON = Path("/home/user/voicebm/pending_active/pending.json")
ENROLL_DIR = Path("/home/user/voicebm/enroll")
STATE_FILE = Path("/home/user/voicebm/meta/auto_enroll_state.json")

# --- config (from add-on options via env) ---
ENABLED = os.environ.get("AUTO_ENROLL_ENABLED", "false").lower() == "true"
MIN_SAMPLES = int(os.environ.get("AUTO_ENROLL_MIN_SAMPLES", "6"))
MIN_COHESION = float(os.environ.get("AUTO_ENROLL_MIN_COHESION", "0.55"))
INTERVAL_S = int(os.environ.get("AUTO_ENROLL_INTERVAL_S", "300"))
PREFIX = os.environ.get("AUTO_ENROLL_PREFIX", "Speaker")


def log(msg):
    print(f"[auto_enroll] {msg}", flush=True)


def load_state():
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return {"next_index": 1, "enrolled_signatures": []}


def save_state(state):
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(state, indent=2))
    except Exception as e:
        log(f"failed to persist state: {e}")


def next_person_name(state):
    """Return a display_name / person_id not already present in enroll/."""
    while True:
        idx = state["next_index"]
        display_name = f"{PREFIX} {idx}"
        person_id = display_name.lower().replace(" ", "_")
        state["next_index"] = idx + 1
        if not (ENROLL_DIR / person_id).exists():
            return display_name, person_id


def pending_ids_present():
    """The enroll command needs a pending_id whose wav+emb exist under
    pending_active/. Only those can be enrolled via the standard path, so we
    intersect cluster members with the current pending buffer."""
    try:
        buf = json.loads(PENDING_JSON.read_text())
        return {e["id"] for e in buf if "id" in e}
    except Exception:
        return set()


def cluster_signature(cluster):
    """A stable-ish fingerprint of a cluster's membership, so we don't
    re-enroll the same group on the next pass before the engine has moved
    its samples out of the unprocessed pool."""
    ids = sorted(s.get("id", "") for s in cluster.get("samples", []))
    return "|".join(ids)


def run_once(client, state):
    try:
        clusters = voice_clustering.generate_clusters(force_refresh=True)
    except Exception as e:
        log(f"clustering failed: {e}")
        return

    if not clusters:
        return

    pend = pending_ids_present()
    already = set(state.get("enrolled_signatures", []))
    enrolled_any = False

    for c in clusters:
        stats = c.get("stats", {}) or {}
        count = stats.get("count", 0)
        cohesion = stats.get("avg_similarity", 0.0)
        likely = c.get("likely_match")

        sig = cluster_signature(c)
        if sig and sig in already:
            continue  # handled on a previous pass

        if count < MIN_SAMPLES:
            continue
        if cohesion < MIN_COHESION:
            log(f"skip cluster {c.get('cluster_id')}: cohesion {cohesion:.2f} < {MIN_COHESION}")
            continue
        if likely and likely.get("person_id"):
            log(f"skip cluster {c.get('cluster_id')}: likely already-enrolled "
                f"{likely.get('display_name')} ({likely.get('confidence', 0):.2f})")
            continue

        # Enroll every member of this cluster that has a live pending entry,
        # under one new person, via the standard enroll command.
        members = [s for s in c.get("samples", []) if s.get("id") in pend]
        if not members:
            # Cluster is real but its samples aren't in the active pending
            # buffer (expired / from passive path). The standard enroll path
            # can't consume them; leave for the dashboard's cluster tools.
            continue

        display_name, person_id = next_person_name(state)
        log(f"auto-enrolling cluster {c.get('cluster_id')} "
            f"({len(members)} pending samples, cohesion {cohesion:.2f}) as '{display_name}'")

        for m in members:
            payload = json.dumps({
                "id": m["id"],
                "person_id": person_id,
                "display_name": display_name,
            })
            client.publish(ENROLL_TOPIC, payload, qos=1)
            time.sleep(0.2)  # let the engine process each move in order

        already.add(sig)
        enrolled_any = True

    if enrolled_any:
        state["enrolled_signatures"] = list(already)[-200:]  # bound growth
        save_state(state)


def main():
    if not ENABLED:
        log("disabled (auto_enroll.enabled = false) — idle")
        # Park so s6 keeps the service 'up' cheaply without restart churn.
        while True:
            time.sleep(3600)

    log(f"enabled — min_samples={MIN_SAMPLES} min_cohesion={MIN_COHESION} "
        f"interval={INTERVAL_S}s prefix='{PREFIX}'")

    cfg = get_mqtt_config()
    client = mqtt.Client()
    if cfg.get("user"):
        client.username_pw_set(cfg["user"], cfg.get("password", ""))

    connected = False
    for attempt in range(30):
        try:
            client.connect(cfg["broker"], int(cfg["port"]), 60)
            connected = True
            break
        except Exception as e:
            log(f"MQTT connect retry ({e})")
            time.sleep(2)
    if not connected:
        log("could not reach MQTT broker after retries — exiting so s6 restarts us")
        sys.exit(1)

    client.loop_start()
    state = load_state()

    try:
        while True:
            run_once(client, state)
            time.sleep(INTERVAL_S)
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()
